# Backers

Website-scraper module is an Open Source Software maintained mostly by one developer in free time. 
Maintaining and developing new features to this project takes a considerable amount of time. 
If website-scraper has helped you in your work or personal projects - you're welcome to make a recurring or one-time pledge. 

If you want to thank the author you can use [Patreon](https://www.patreon.com/s0ph1e) or [GitHub Sponspors](https://github.com/sponsors/s0ph1e/).
Thank you for your support ❤️

### Backers via Patreon
* The Rubyist

### Backers via GitHub Sponspors
* swcarlosrj 
* francescamarano
