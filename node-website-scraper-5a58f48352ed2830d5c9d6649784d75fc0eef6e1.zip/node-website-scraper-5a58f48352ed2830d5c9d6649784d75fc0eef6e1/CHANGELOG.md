# Changelog

Website-scraper’s changelog can be found directly in the [GitHub release notes](https://github.com/website-scraper/node-website-scraper/releases). 
